# Sources, rationale and limits

## Source assets

Both JPEGs were supplied in `WhatsApp Image 2026-09-21 at 2.47.59 PM.zip`.
They are preserved byte-for-byte in the source package.

| Asset | Original filename | Verified pixels | Package path |
|---|---|---|---|
| Official logo | WhatsApp Image 2026-09-21 at 2.47.59 PM.jpeg | 1254 × 1254 | assets/originals/01.jpeg |
| Kitchen photograph | WhatsApp Image 2026-10-20 at 10.04.49 AM.jpeg | 1200 × 896 | assets/originals/02.jpeg |

Kitchen SHA-256:
`fc7fea545785547e3fc97d341e8a977ad9c02b718837111a3ab1714f33414f0f`

Logo SHA-256:
`9e6b4a73f4e5a4e821a25adf1397119957bff1f77a3ef02fcc933b6b0f4ef0a3`

The two original files and their inline previews were visually inspected.
Both files are RGB JPEGs without embedded ICC profiles or EXIF orientation tags.
They are treated as sRGB. Existing color, geometry and reflections are retained.
Crop resampling does not create new source detail.

The client brief is preserved at `docs/original-brief.txt`. The user explicitly
confirmed an on-site photograph and confirmed that the greige upper fronts are
acrylic. The completed-project claim is based on that confirmation; independent
photographic provenance verification was not possible.

Interior melamine and Soft-close are client-provided specifications. No interior
photograph or mechanism footage was supplied. Exterior stills cannot verify
those mechanisms, and the film labels them as client-provided specifications.

## Cairo font

Google Fonts / Cairo, SIL Open Font License 1.1. Font and license are bundled.
Downloaded with normal TLS verification:

https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/Cairo%5Bslnt,wght%5D.ttf

Font SHA-256:
`667c987182391c91f4e57a2f455b1794fb5e3ee6ca4ef3383e86bb690fa9c964`

License:
https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/OFL.txt

License SHA-256:
`a4554e1799d42e1405924b61eb0e0722ae1623b1f1f07f995348f96c496362a9`

Arabic is shaped by libraqm/HarfBuzz. Phone numbers use explicit left-to-right
direction.

## Research attempts — not reviewed references

The environment network proxy returned HTTP 403 for these official studio sites:

- https://www.ordinaryfolk.co/work
- https://www.manvsmachine.co.uk/work
- https://www.zeligsound.com/

No film on these sites was viewed or heard. The requested review of recent
motion/sound references could not be completed. No trend or reference-film
claims are made.

## Creative rationale

Use the cabinet grid to motivate the opening reveal, then use brief continuous
reframing of the same photo and allow every composition to settle. Pair the full
landscape image with a detail crop from the same photograph to maintain room
context. Straight-edge transitions remain inside that separate detail ribbon.
Separate imagery from cream-panel Arabic typography, and use charcoal/brass
accents sparingly.

The still drawer crop and the longer reading pause carry the Soft-close
section. No mechanism motion or closing foley is invented. The final card
uses the complete supplied logo, larger contact copy, and a static hold.

## Audio

No music or effects were supplied or licensed. The final master is silent and
contains no audio stream. `audio-cues.csv` is a separate production cue sheet
for a warm 96 BPM score. It is not finished sound design.

## Remaining limits

- One photograph cannot provide additional camera views, cabinet interiors,
  real material close-ups beyond its resolution, or a mechanism demonstration.
- All imagery is editorial motion from this still; it is not a multi-shot shoot.
- Recent studio-reference research was inaccessible.
- Browser playback and decoded-frame review were performed. Continuous human
  video viewing and subjective listening were not available; see QA details.
- The phone line has about 330 pixels of lower margin. Social-platform overlays
  vary, so no universal placement guarantee is made.
- No publication or external upload occurred.
