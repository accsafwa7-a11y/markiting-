# Storyboard — من تنفيذنا… لتفاصيل يومك

Status: final edit delivered as a silent master, using the two original JPEG
files supplied in the ZIP. Technical and visual-review limits are recorded in
`qa-status.md`.

## Asset review

- **Kitchen:** one landscape view of the L-shaped installation. Strongest and
  only complete view. The refrigerator at left, sink at center, dark-framed
  glass units above, window and cooker at right establish the room clearly.
  Warm wood, greige fronts and existing light are the visual story.
- **Provenance:** the user explicitly confirmed an on-site photograph of the
  completed installation. This confirmation is the basis for execution copy;
  the photograph's authenticity has not been independently verified.
- **Acrylic:** the user explicitly confirmed the greige upper fronts are
  acrylic. Detail framing concentrates on those fronts, not the wood grain.
- **Usable crops:** upper-front seam and under-cabinet light; display-cabinet
  frames; wood fronts and plinth; visible drawer bank left of the cooker.
  Crops cannot reveal new architecture, interiors or motion.
- **Interior imagery:** none supplied. The melamine specification comes from
  the client brief. Keep a composed exterior image and label the specification.
- **Soft-close footage:** none supplied. Use a static drawer-region crop.
  No moving drawer and no foley implying a closing demonstration.
- **Logo:** supplied black-square official ELSAFWA FURNITURE artwork with
  Arabic/English text and gold chair monogram. Preserve the complete artwork.
- **Resolution:** original JPEG dimensions verified as 1200 × 896 for the kitchen
  and 1254 × 1254 for the logo. Both are RGB, without embedded ICC profiles or
  EXIF orientation tags. Source sharpness is limited to these supplied files;
  detail crops use modest resampling, not reconstruction.
- **Audio:** none supplied. Deliver silent master with a separate cue sheet.

## Editorial structure

The main image sits across the full 1080-pixel width, preserving the landscape
composition. A narrow crop below it shows a selected detail from the
same photograph. Together the image zones occupy about 60% of the vertical
canvas until the final card. At the close the detail strip becomes shallower,
leaving about half the screen for the full-room image and detail combined. This
allows a larger intact logo and a phone line above the bottom 330 pixels.
Typography is in a cream panel below. The source photograph is never stretched,
retouched or expanded.

| Time / frames | Image and motion | Arabic copy in lower panel | Sound plan only |
|---|---|---|---|
| 00–03 / 0–179 | Recognizable kitchen and detail strip from frame zero. Charcoal matte begins at an upper-cabinet seam and reveals the right side in 0.5 s. Hold the near-wide view. | من تنفيذ الصفوة للأثاث | Planned only: restrained tonal attack; no mechanism sound. |
| 03–07 / 180–419 | Brief continuous reframe into the complete image. Straight-edge wipe in the separate warm plinth/wood detail strip. Settle and hold. | 03–05: مطبخ يلفت النظر / 05–07: وتفاصيل تريحك كل يوم | Gentle expansion near 3 s. |
| 07–11.5 / 420–689 | Restrained crop toward the confirmed greige acrylic fronts. Existing reflections remain unchanged. | درف أكريليك / لمسة مودرن وانعكاس أنيق للإضاءة | One soft graphic accent, then space. |
| 11.5–16 / 690–959 | Exterior composition and wood/plinth detail. No fabricated cabinet interior. | تقفيل داخلي ميلامين معالج / تفاصيل تهمّك في الاستخدام اليومي / small: مواصفة مقدّمة من العميل | Thin out percussion. |
| 16–21 / 960–1259 | Same still reframed toward the drawer bank. Settle the image and allow reading time. | مفصلات وأدراج / Soft-close / قفل هادي… وراحة كل يوم / small: مواصفة مقدّمة من العميل | Quiet musical section. No drawer or door-closing foley. |
| 21–25.5 / 1260–1529 | Return to the complete kitchen with a glass-cabinet detail strip. Calm hold. | 21–23.25: تفاصيل اجتمعت… / 23.25–25.5: والنتيجة من تنفيذنا | Warm return of harmony. |
| 25.5–30 / 1530–1799 | Complete kitchen stays visible. Larger intact logo at left of lower panel, CTA to its right, phone line centered below. Motion ends by 26.2 s, then hold. | مطبخك الجاي يبدأ بمقاساتك / ابعتلنا واستفسر عن التصميم والتنفيذ / 01080205052 / 01014250304 | Resolved ending, natural tail to silence. |

The entire delivered film is silent. All entries in the sound column describe
the separate cue sheet, not an implemented soundtrack.

## Self-critique before animation

**Is this a distinctive kitchen film, or a slideshow decorated with effects?**

The distinguishing device is the relationship between the complete room and a
detail sampled from it. Each crop supports the current message, while the room
stays spatially understandable. Brief alignment-based transitions separate long
settled compositions. Phrase changes create rhythm without adding false evidence.

There is only one actual visual moment. Thirty seconds is enough for the seven
messages but requires generous reading pauses; it cannot provide the cinematic
variety of a multi-shot shoot. The material/interior/Soft-close sequence must not
be disguised as three documented demonstrations. If the real export feels
repetitive, simplify the crop changes and give the hero longer holds.

No simulated orbit, depth animation, opening cabinet, manufactured reflection
or invented installation footage is used.

## Iteration after the first render

The first real-asset render showed a small final logo and unnecessary numbered
slide counters. The final edit removes the counters, increases the logo from
230 to 360 pixels, replaces the opening shaded strip with a flat editorial
reveal, and raises the phone line. The specification label is shorter and
larger. The final card gives up some detail-strip height to protect contact
legibility; the complete kitchen view remains the same size.

Decoded transition frames exposed duplicated cabinet edges in main-image wipes.
The final main-image transitions use brief continuous reframing of the same
source instead. Straight-edge wipes remain only within the separate detail
ribbon. Each main-image frame retains a coherent cabinet grid.

## Caption A — completed project

من تنفيذ الصفوة للأثاث… لتفاصيل يومك ✨

مطبخ يجمع دفء الخشب، هدوء الألوان، وإضاءة تكمّل كل تفصيلة.
تصميم متناسق ونتيجة نفتخر بتنفيذها.

مطبخك الجاي يبدأ بمقاساتك.
ابعتلنا واستفسر عن التصميم والتنفيذ.

01080205052 / 01014250304

#الصفوة_للأثاث #مطابخ #تصميم_مطابخ

## Caption B — materials and everyday comfort

الجمال في الشكل… والراحة في التفاصيل.

درف أكريليك، تقفيل داخلي ميلامين معالج، ومفصلات وأدراج Soft-close.
تفاصيل اختيرت علشان استخدامك اليومي يكون أريح.

مع الصفوة للأثاث، نبدأ بمقاسات مطبخك ونتكلم عن التصميم والتنفيذ المناسبين لك.

01080205052 / 01014250304

#الصفوة_للأثاث #مطابخ_مودرن #تفاصيل_تريحك

Caption specifications come from the client brief; no waterproofing, lifespan,
board-grade or WhatsApp claim is added.
